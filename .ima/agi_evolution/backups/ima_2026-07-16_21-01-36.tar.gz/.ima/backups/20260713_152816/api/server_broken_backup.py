#!/usr/bin/env python3
from http.server import BaseHTTPRequestHandler, HTTPServer
import json,time,sys
from pathlib import Path
MEMORY_FILE=Path("ima_memory.json")

sys.path.insert(0,".")

try:
    from learning import meta_orchestrator
    class Brain:
        def process(self, question):
            q = question.lower()

            if "מי זאת" in question or "אמא" in question or "ima" in q:
                identity = Path("IMA_IDENTITY.md").read_text(encoding="utf-8")
                return {
                    "response": "אני IMA. מערכת שנבנתה כדי לחבר בין טכנולוגיה, ידע, זיכרון, למידה וצמיחה אנושית.",
                    "identity": "IMA",
                    "identity_source": "IMA_IDENTITY.md",
                    "identity_document": identity[:3000],
                    "meta": meta_orchestrator.run_meta_analysis()
                }

            if "למה" in question or "איך" in question:
                return {
                    "response": "אני מקשיבה. כרגע אני מחוברת למנוע הידע והניתוח שלי.",
                    "meta": meta_orchestrator.run_meta_analysis()
                }

            return {
                "response": "קיבלתי: " + question,
                "meta": meta_orchestrator.run_meta_analysis()
            }

        def run_meta_analysis(self):
            if "קוראים לי אורי" in question:
            return {"response":"זכרתי. השם שנמסר לי הוא אורי.","memory":self.long_memory}

        return {"response":"קיבלתי: "+question,"context":self.memory[-5:],"memory":self.long_memory}

    BRAIN=Brain()
except Exception as e:
    BRAIN=None
    ERROR=str(e)


class Handler(BaseHTTPRequestHandler):

    def send_json(self,data):
        body=json.dumps(data,ensure_ascii=False).encode()
        self.send_response(200)
        self.send_header("Content-Type","application/json")
        self.send_header("Access-Control-Allow-Origin","*")
        self.send_header("Access-Control-Allow-Headers","Content-Type")
        self.send_header("Access-Control-Allow-Methods","GET, POST, OPTIONS")
        self.end_headers()
        self.wfile.write(body)


    def do_GET(self):

        if self.path=="/":
            self.send_json({
                "product":"IMA",
                "status":"ONLINE",
                "runtime":"canonical",
                "brain":BRAIN is not None
            })

        elif self.path=="/health":
            self.send_json({
                "health":"ok",
                "brain":BRAIN is not None
            })

        else:
            self.send_json({"error":"not_found"})


    def do_POST(self):

        if self.path=="/ask":

            size=int(self.headers.get("Content-Length",0))
            data=json.loads(self.rfile.read(size))

            question=data.get("message","")

            if BRAIN:
                try:
                    answer=BRAIN.process(question)
                except Exception as e:
                    answer={"error":str(e)}
            else:
                answer={"error":"brain_offline"}

            self.send_json({
                "input":question,
                "answer":answer,
                "time":int(time.time())
            })

        else:
            self.send_json({"error":"not_found"})


print("IMA API ONLINE :8080")
HTTPServer(("0.0.0.0",8080),Handler).serve_forever()
