// IMA unified state manager
