#!/usr/bin/env bash
set -e

echo "[IMA RELEASE]"
echo "================"

echo "[1] version bump"
node -e "
const fs=require('fs');
const p=require('./package.json');

let [maj,min,pat]=(p.version||'1.0.0').split('.');
maj=parseInt(maj||1);
min=parseInt(min||0);
pat=parseInt(pat||0)+1;

p.version=\`\${maj}.\${min}.\${pat}\`;

fs.writeFileSync('package.json',JSON.stringify(p,null,2));
console.log('[VERSION]',p.version);
"

echo "[2] git commit + tag"
git add .
git commit -m "release $(node -e "console.log(require('./package.json').version)")"
git tag "v$(node -e "console.log(require('./package.json').version)")"

echo "[3] npm publish"
npm publish

echo "[4] git push"
git push && git push --tags

echo "[5] sync hooks (future extension point)"
echo "sync: web + app + devices ready hook"

echo "================"
echo "[RELEASE DONE]"
